﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 9/4/2024
 * Time: 1:01 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace editorMeci
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox textBox15;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBox16;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox textBox17;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBox18;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.PictureBox logoGazda;
		private System.Windows.Forms.PictureBox logoOaspete;
		private System.Windows.Forms.PictureBox Stadionul;
		private System.Windows.Forms.PictureBox steagOras;
		private System.Windows.Forms.PictureBox steagTara;
		private System.Windows.Forms.PictureBox logoCompetitia;
		private System.Windows.Forms.PictureBox logopostulTV;
		private System.Windows.Forms.PictureBox echipaGazda;
		private System.Windows.Forms.PictureBox echipaOaspete;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label16;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.textBox18 = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.logoGazda = new System.Windows.Forms.PictureBox();
			this.logoOaspete = new System.Windows.Forms.PictureBox();
			this.Stadionul = new System.Windows.Forms.PictureBox();
			this.steagOras = new System.Windows.Forms.PictureBox();
			this.steagTara = new System.Windows.Forms.PictureBox();
			this.logoCompetitia = new System.Windows.Forms.PictureBox();
			this.logopostulTV = new System.Windows.Forms.PictureBox();
			this.echipaGazda = new System.Windows.Forms.PictureBox();
			this.echipaOaspete = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.label16 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.logoGazda)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.logoOaspete)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.Stadionul)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.steagOras)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.steagTara)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.logoCompetitia)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.logopostulTV)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.echipaGazda)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.echipaOaspete)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Editor Meci";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(205, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "Echipa Gazda";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(204, 137);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(310, 20);
			this.textBox1.TabIndex = 2;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(773, 137);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(310, 20);
			this.textBox2.TabIndex = 4;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(1005, 110);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 3;
			this.label3.Text = "Echipa Oaspete";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(536, 136);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(44, 20);
			this.textBox3.TabIndex = 5;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(586, 136);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(44, 20);
			this.textBox4.TabIndex = 7;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(536, 110);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(94, 23);
			this.label5.TabIndex = 8;
			this.label5.Text = "Scor";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(655, 110);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(94, 23);
			this.label4.TabIndex = 11;
			this.label4.Text = "Scor Pauza";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(705, 136);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(44, 20);
			this.textBox5.TabIndex = 10;
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(655, 136);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(44, 20);
			this.textBox6.TabIndex = 9;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(1277, 111);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(94, 23);
			this.label6.TabIndex = 17;
			this.label6.Text = "Scor Penaltiuri";
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(1327, 137);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(44, 20);
			this.textBox7.TabIndex = 16;
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(1277, 137);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(44, 20);
			this.textBox8.TabIndex = 15;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(1159, 111);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(94, 23);
			this.label7.TabIndex = 14;
			this.label7.Text = "Scor Prelungiri";
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(1209, 137);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(44, 20);
			this.textBox9.TabIndex = 13;
			// 
			// textBox10
			// 
			this.textBox10.Location = new System.Drawing.Point(1159, 137);
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(44, 20);
			this.textBox10.TabIndex = 12;
			// 
			// textBox11
			// 
			this.textBox11.Location = new System.Drawing.Point(205, 197);
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(310, 20);
			this.textBox11.TabIndex = 19;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(206, 170);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(100, 23);
			this.label8.TabIndex = 18;
			this.label8.Text = "Stadion";
			// 
			// textBox12
			// 
			this.textBox12.Location = new System.Drawing.Point(536, 197);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(310, 20);
			this.textBox12.TabIndex = 21;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(537, 170);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(100, 23);
			this.label9.TabIndex = 20;
			this.label9.Text = "Oras";
			// 
			// textBox13
			// 
			this.textBox13.Location = new System.Drawing.Point(852, 197);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(310, 20);
			this.textBox13.TabIndex = 23;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(853, 170);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(100, 23);
			this.label10.TabIndex = 22;
			this.label10.Text = "Competitia";
			// 
			// textBox14
			// 
			this.textBox14.Location = new System.Drawing.Point(1168, 197);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(203, 20);
			this.textBox14.TabIndex = 25;
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(1169, 170);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(100, 23);
			this.label11.TabIndex = 24;
			this.label11.Text = "Ora si Data start";
			// 
			// textBox15
			// 
			this.textBox15.Location = new System.Drawing.Point(537, 249);
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(310, 20);
			this.textBox15.TabIndex = 27;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(538, 222);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(100, 23);
			this.label12.TabIndex = 26;
			this.label12.Text = "Tara";
			// 
			// textBox16
			// 
			this.textBox16.Location = new System.Drawing.Point(206, 249);
			this.textBox16.Name = "textBox16";
			this.textBox16.Size = new System.Drawing.Size(310, 20);
			this.textBox16.TabIndex = 29;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(207, 222);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(100, 23);
			this.label13.TabIndex = 28;
			this.label13.Text = "Numar Spectatori";
			// 
			// textBox17
			// 
			this.textBox17.Location = new System.Drawing.Point(853, 249);
			this.textBox17.Name = "textBox17";
			this.textBox17.Size = new System.Drawing.Size(310, 20);
			this.textBox17.TabIndex = 31;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(854, 222);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(308, 23);
			this.label14.TabIndex = 30;
			this.label14.Text = "Transmis De Postul TV, Radio, Internet";
			// 
			// textBox18
			// 
			this.textBox18.Location = new System.Drawing.Point(1169, 249);
			this.textBox18.Name = "textBox18";
			this.textBox18.Size = new System.Drawing.Size(203, 20);
			this.textBox18.TabIndex = 33;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(1170, 222);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(100, 23);
			this.label15.TabIndex = 32;
			this.label15.Text = "Ora si Data final";
			// 
			// logoGazda
			// 
			this.logoGazda.Location = new System.Drawing.Point(394, 23);
			this.logoGazda.Name = "logoGazda";
			this.logoGazda.Size = new System.Drawing.Size(120, 108);
			this.logoGazda.TabIndex = 34;
			this.logoGazda.TabStop = false;
			// 
			// logoOaspete
			// 
			this.logoOaspete.Location = new System.Drawing.Point(773, 23);
			this.logoOaspete.Name = "logoOaspete";
			this.logoOaspete.Size = new System.Drawing.Size(120, 108);
			this.logoOaspete.TabIndex = 35;
			this.logoOaspete.TabStop = false;
			// 
			// Stadionul
			// 
			this.Stadionul.Location = new System.Drawing.Point(12, 161);
			this.Stadionul.Name = "Stadionul";
			this.Stadionul.Size = new System.Drawing.Size(174, 108);
			this.Stadionul.TabIndex = 36;
			this.Stadionul.TabStop = false;
			// 
			// steagOras
			// 
			this.steagOras.Location = new System.Drawing.Point(538, 23);
			this.steagOras.Name = "steagOras";
			this.steagOras.Size = new System.Drawing.Size(92, 84);
			this.steagOras.TabIndex = 37;
			this.steagOras.TabStop = false;
			// 
			// steagTara
			// 
			this.steagTara.Location = new System.Drawing.Point(655, 23);
			this.steagTara.Name = "steagTara";
			this.steagTara.Size = new System.Drawing.Size(92, 84);
			this.steagTara.TabIndex = 38;
			this.steagTara.TabStop = false;
			// 
			// logoCompetitia
			// 
			this.logoCompetitia.Location = new System.Drawing.Point(12, 47);
			this.logoCompetitia.Name = "logoCompetitia";
			this.logoCompetitia.Size = new System.Drawing.Size(174, 108);
			this.logoCompetitia.TabIndex = 39;
			this.logoCompetitia.TabStop = false;
			// 
			// logopostulTV
			// 
			this.logopostulTV.Location = new System.Drawing.Point(988, 23);
			this.logopostulTV.Name = "logopostulTV";
			this.logopostulTV.Size = new System.Drawing.Size(174, 84);
			this.logopostulTV.TabIndex = 40;
			this.logopostulTV.TabStop = false;
			// 
			// echipaGazda
			// 
			this.echipaGazda.Location = new System.Drawing.Point(12, 275);
			this.echipaGazda.Name = "echipaGazda";
			this.echipaGazda.Size = new System.Drawing.Size(687, 356);
			this.echipaGazda.TabIndex = 41;
			this.echipaGazda.TabStop = false;
			// 
			// echipaOaspete
			// 
			this.echipaOaspete.Location = new System.Drawing.Point(715, 275);
			this.echipaOaspete.Name = "echipaOaspete";
			this.echipaOaspete.Size = new System.Drawing.Size(687, 356);
			this.echipaOaspete.TabIndex = 42;
			this.echipaOaspete.TabStop = false;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(1327, 23);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(93, 67);
			this.button1.TabIndex = 43;
			this.button1.Text = "generateXML";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(1246, 23);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 67);
			this.button2.TabIndex = 44;
			this.button2.Text = "generate string";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(1246, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(174, 23);
			this.label16.TabIndex = 45;
			this.label16.Text = "label16";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1432, 643);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.echipaOaspete);
			this.Controls.Add(this.echipaGazda);
			this.Controls.Add(this.logopostulTV);
			this.Controls.Add(this.logoCompetitia);
			this.Controls.Add(this.steagTara);
			this.Controls.Add(this.steagOras);
			this.Controls.Add(this.Stadionul);
			this.Controls.Add(this.logoOaspete);
			this.Controls.Add(this.logoGazda);
			this.Controls.Add(this.textBox18);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.textBox17);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.textBox16);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.textBox15);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.textBox14);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.textBox13);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.textBox12);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.textBox11);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.textBox7);
			this.Controls.Add(this.textBox8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.textBox9);
			this.Controls.Add(this.textBox10);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.textBox5);
			this.Controls.Add(this.textBox6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "MainForm";
			this.Text = "editorMeci";
			this.Load += new System.EventHandler(this.MainFormLoad);
			((System.ComponentModel.ISupportInitialize)(this.logoGazda)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.logoOaspete)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.Stadionul)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.steagOras)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.steagTara)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.logoCompetitia)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.logopostulTV)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.echipaGazda)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.echipaOaspete)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
